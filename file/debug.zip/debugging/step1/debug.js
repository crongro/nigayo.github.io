
function step1() {
	console.log("step1 called");
	step2();
}

function step2() {
	console.log("step2 called");
	step3();
}

function step3() {

	sendAjax('data.json');

	for (var i = 10; i >= 0; i--) {
		stepInto(i);
	}
}

function stepInto(nCount) {
	console.log("loop count : ", nCount);
}

function sendAjax(sURL) {

	var xmlhttp=new XMLHttpRequest();

	xmlhttp.onreadystatechange=function() {
		if (xmlhttp.readyState==4 && xmlhttp.status==200) {
			sData = JSON.parse(xmlhttp.responseText);
			_insertData(sData);
		}
	}

	xmlhttp.open("GET",sURL,true);
	xmlhttp.send();
}

function _insertData(sData) {
	//debugger;
	document.getElementById("result").innerHTML = sData.feature.join(", ");
}

document.body.addEventListener("click", step1 ,false);
